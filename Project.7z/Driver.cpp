#include "DFA.hpp"
int main()
{
    //DFA 1

    DFA dfa(4, "A", true);
    dfa.addState("B", 1);
    dfa.addState("C", 1);
    dfa.addState("D", 0);
    dfa.addTranstions("A", "A", 'b');
    dfa.addTranstions("A", "B", 'a');
    dfa.addTranstions("B", "B", 'a');
    dfa.addTranstions("B", "C", 'b');
    dfa.addTranstions("C", "C", 'b');
    dfa.addTranstions("C", "D", 'a');
    dfa.addTranstions("D", "D", 'b');
    dfa.addTranstions("D", "D", 'a');

    //DFA example 2
    /*
    DFA dfa(2, "q1", false);

    dfa.addState("q2", 1);
    dfa.addTranstions("q1", "q2", 'a');
    dfa.addTranstions("q1", "q1", 'c');
    dfa.addTranstions("q2", "q1", 'b');
    dfa.addTranstions("q2", "q2", 'd');
*/

    //DFA example 3
    /*
    DFA dfa(5, "q1", false);

    dfa.addState("q2", 0);
    dfa.addState("q3", 1);
    dfa.addState("q4", 1);
    dfa.addState("q5", 1);
    dfa.addTranstions("q1", "q2", 'a');
    dfa.addTranstions("q2", "q3", 'c');
    dfa.addTranstions("q2", "q4", 'b');
    dfa.addTranstions("q2", "q5", 'd');

    */
    dfa.displayDFA();
    dfa.DFAtoRegex();

    // std::cout << dfa.checkinput("ababb");
}